/**
 * Single source of truth for all portfolio content.
 * Anything marked `placeholder: true` (or wrapped in [brackets]) is a stand-in:
 * replace it with your real details. Nothing here is invented history or metrics.
 */

export const profile = {
  name: "Your Name", // TODO: replace
  wordmark: "YN", // TODO: initials shown in the nav
  role: "Software Developer",
  years: 3,
  location: "[City, Country]", // TODO: replace
  email: "hello@example.com", // TODO: replace
  linkedin: "https://www.linkedin.com/in/your-handle", // TODO: replace
  github: "https://github.com/your-handle", // TODO: replace
  available: true,
  availability: "Available for new opportunities",
};

export const navItems = [
  { id: "about", label: "About" },
  { id: "experience", label: "Experience" },
  { id: "projects", label: "Projects" },
  { id: "skills", label: "Skills" },
  { id: "contact", label: "Contact" },
];

export const about = {
  lead: "I sit between design and engineering — shaping interfaces people enjoy using, and the systems that quietly make them work.",
  paragraphs: [
    "I'm a software developer with three years of experience across frontend engineering, UI/UX design and backend development. I started from the interface and worked my way down the stack, which is why I care as much about a well-named endpoint as a well-set heading.",
    "My day-to-day is React and modern CSS on the front, Python and FastAPI on the back, with PostgreSQL or MongoDB underneath. I design in Figma first when a problem is still fuzzy, then build it properly.",
    "Lately I've been exploring artificial intelligence: integrating LLMs into real products, and designing the interfaces that make intelligent features understandable rather than magical.",
  ],
  pillars: [
    { label: "Frontend Engineering", note: "React, Tailwind, SCSS" },
    { label: "UI / UX Design", note: "Figma, interface systems" },
    { label: "Backend Development", note: "Python, FastAPI, REST" },
    { label: "AI & Intelligent Apps", note: "LLM integrations" },
  ],
};

export interface ExperienceEntry {
  company: string;
  position: string;
  duration: string;
  responsibilities: string[];
  technologies: string[];
  placeholder?: boolean;
}

// Placeholder entries — replace with your real employment history.
export const experience: ExperienceEntry[] = [
  {
    company: "[Company Name]",
    position: "[Software Developer]",
    duration: "[Start] — Present",
    responsibilities: [
      "[Describe a responsibility, e.g. building and maintaining user-facing features.]",
      "[Describe a second responsibility, e.g. collaborating with design and backend teams.]",
      "[Describe a third responsibility, e.g. integrating APIs and data sources.]",
    ],
    technologies: ["React.js", "Tailwind CSS", "Python", "FastAPI"],
    placeholder: true,
  },
  {
    company: "[Previous Company]",
    position: "[Previous Position]",
    duration: "[Start] — [End]",
    responsibilities: [
      "[Describe a responsibility.]",
      "[Describe another responsibility.]",
    ],
    technologies: ["JavaScript", "Sass / SCSS", "PostgreSQL"],
    placeholder: true,
  },
];

export interface Project {
  index: string;
  name: string;
  category: string;
  overview: string;
  contribution: string;
  technologies: string[];
  demoUrl?: string;
  repoUrl?: string;
  /** Path under /public, e.g. "/projects/gpu.png". Falls back to a generated placeholder. */
  image?: string;
  accent: "ink" | "accent" | "paper";
}

export const projects: Project[] = [
  {
    index: "01",
    name: "GPU Monitoring Dashboard",
    category: "Web Application · Data Visualization",
    overview:
      "A dashboard for observing GPU resources — utilisation, memory and temperature — designed so the state of a machine can be read at a glance.",
    contribution:
      "[Describe your contribution: interface design, React implementation, data integration…]",
    technologies: ["React.js", "Tailwind CSS", "REST APIs", "Python"],
    accent: "ink",
  },
  {
    index: "02",
    name: "AI-Powered Chatbot",
    category: "AI · LLM Application",
    overview:
      "A conversational assistant built on a large language model, with a focus on a clear chat interface and a backend that keeps the model integration simple to maintain.",
    contribution:
      "[Describe your contribution: prompt design, API layer, chat UI…]",
    technologies: ["Python", "FastAPI", "React.js", "LLM APIs"],
    accent: "accent",
  },
  {
    index: "03",
    name: "CRM Management System",
    category: "Full-Stack Application",
    overview:
      "A customer relationship management system for organising contacts and interactions in one place, with a structured data model behind a clean interface.",
    contribution:
      "[Describe your contribution: schema design, API endpoints, UI screens…]",
    technologies: ["React.js", "FastAPI", "PostgreSQL", "REST APIs"],
    accent: "paper",
  },
  {
    index: "04",
    name: "Network Infrastructure Management",
    category: "Internal Tool · Systems",
    overview:
      "A tool for managing and viewing network infrastructure, bringing devices and their relationships into a single, navigable interface.",
    contribution:
      "[Describe your contribution: features built, integrations, interface decisions…]",
    technologies: ["React.js", "Python", "MongoDB", "REST APIs"],
    accent: "ink",
  },
];

export const skills = [
  {
    group: "Frontend Development",
    items: ["HTML", "CSS", "JavaScript", "React.js", "Tailwind CSS", "Sass / SCSS"],
  },
  {
    group: "Backend Development",
    items: ["Python", "FastAPI", "REST APIs"],
  },
  { group: "Databases", items: ["PostgreSQL", "MongoDB"] },
  { group: "UI/UX Design", items: ["Figma", "Interface design", "Prototyping"] },
  {
    group: "AI & Automation",
    items: ["LLM-based applications", "AI integrations"],
  },
  { group: "Development Tools", items: ["Git", "GitHub"] },
];

export const contact = {
  heading: "Let's build something thoughtful together.",
  closing:
    "Whether it's a product, a prototype or a team that needs another pair of hands — I'd like to hear about it. I reply to every message.",
};

import type { Config } from "tailwindcss";

const config: Config = {
  content: ["./src/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        paper: "#EFECE6",
        "paper-2": "#E6E2DA",
        ink: "#121110",
        muted: "#6B665E",
        accent: "#D9482B",
      },
      fontFamily: {
        serif: ["var(--font-serif)", "Georgia", "serif"],
        sans: ["var(--font-sans)", "system-ui", "sans-serif"],
        mono: ["var(--font-mono)", "ui-monospace", "monospace"],
      },
      keyframes: {
        spin360: { to: { transform: "rotate(360deg)" } },
        pulseDot: {
          "0%,100%": { opacity: "1", transform: "scale(1)" },
          "50%": { opacity: ".35", transform: "scale(.7)" },
        },
        scrollLine: {
          "0%": { transform: "translateY(-100%)" },
          "100%": { transform: "translateY(100%)" },
        },
      },
      animation: {
        "spin-slow": "spin360 60s linear infinite",
        "spin-rev": "spin360 90s linear infinite reverse",
        pulseDot: "pulseDot 2s ease-in-out infinite",
        scrollLine: "scrollLine 2s cubic-bezier(.65,0,.35,1) infinite",
      },
    },
  },
  plugins: [],
};
export default config;

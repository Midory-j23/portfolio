import { experience } from "@/data/content";
import { Reveal } from "./Reveal";
import { SectionHeading } from "./SectionHeading";

export function Experience() {
  return (
    <section id="experience" className="bg-paper-2 py-28 md:py-44">
      <div className="container-x">
        <SectionHeading index="02" label="Experience" lines={["Where I've", <>been <em>working.</em></>]} />

        <ol className="relative">
          <span aria-hidden className="absolute bottom-0 left-[5px] top-2 w-px bg-ink/20 md:left-[calc(25%-1px)]" />
          {experience.map((job, i) => (
            <li key={i} className="relative grid grid-cols-12 gap-y-6 pb-20 pl-8 last:pb-0 md:pl-0">
              <span
                aria-hidden
                className={`absolute left-0 top-2 h-[11px] w-[11px] rounded-full border border-ink md:left-[calc(25%-6px)] ${
                  i === 0 ? "bg-accent border-accent" : "bg-paper-2"
                }`}
              />
              <Reveal className="col-span-12 md:col-span-3">
                <p className="eyebrow !text-ink">{job.duration}</p>
                {job.placeholder && (
                  <p className="eyebrow mt-2 inline-block border border-ink/30 px-2 py-1">
                    Placeholder
                  </p>
                )}
              </Reveal>

              <Reveal delay={0.1} className="col-span-12 md:col-span-8 md:col-start-5 md:pl-10">
                <h3 className="font-serif text-4xl leading-none md:text-6xl">{job.company}</h3>
                <p className="mt-3 text-lg text-muted">{job.position}</p>
                <ul className="mt-8 space-y-3 text-base leading-relaxed text-ink/80 md:text-lg">
                  {job.responsibilities.map((r, j) => (
                    <li key={j} className="flex gap-4">
                      <span aria-hidden className="mt-[0.85em] h-px w-4 shrink-0 bg-ink/50" />
                      {r}
                    </li>
                  ))}
                </ul>
                <ul className="mt-8 flex flex-wrap gap-2" aria-label="Technologies used">
                  {job.technologies.map((t) => (
                    <li key={t} className="eyebrow border border-ink/25 px-3 py-1.5 !text-ink">
                      {t}
                    </li>
                  ))}
                </ul>
              </Reveal>
            </li>
          ))}
        </ol>
      </div>
    </section>
  );
}

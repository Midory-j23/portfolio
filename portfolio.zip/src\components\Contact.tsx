import { contact, profile } from "@/data/content";
import { LineReveal, Reveal } from "./Reveal";

const links = [
  { label: "LinkedIn", href: profile.linkedin },
  { label: "GitHub", href: profile.github },
];

export function Contact() {
  return (
    <footer id="contact" className="bg-ink pt-28 text-paper md:pt-44">
      <div className="container-x">
        <Reveal className="mb-8 flex items-center gap-4 border-t border-paper/20 pt-4">
          <span className="eyebrow !text-accent">05</span>
          <span className="eyebrow !text-paper/60">Contact</span>
        </Reveal>

        <LineReveal
          className="h-display text-[clamp(2.75rem,8vw,7.5rem)]"
          lines={["Let’s build something", <>thoughtful <em className="text-accent">together.</em></>]}
        />

        <div className="mt-16 grid grid-cols-12 gap-y-12">
          <Reveal className="col-span-12 lg:col-span-5">
            <p className="max-w-md text-lg leading-relaxed text-paper/75">{contact.closing}</p>
            <a
              href={`mailto:${profile.email}`}
              className="focus-ring group mt-10 inline-flex items-center gap-3 bg-paper px-7 py-4 text-sm text-ink transition-colors hover:bg-accent hover:text-paper"
            >
              Start a conversation
              <span className="transition-transform duration-300 group-hover:translate-x-1" aria-hidden>→</span>
            </a>
          </Reveal>

          <Reveal delay={0.1} className="col-span-12 lg:col-span-6 lg:col-start-7">
            <ul className="border-t border-paper/20">
              <li>
                <a
                  href={`mailto:${profile.email}`}
                  className="focus-ring group flex items-baseline justify-between gap-4 border-b border-paper/20 py-6"
                >
                  <span className="eyebrow !text-paper/50">Email</span>
                  <span className="break-all font-serif text-2xl transition-colors group-hover:text-accent md:text-4xl">
                    {profile.email}
                  </span>
                </a>
              </li>
              {links.map((l) => (
                <li key={l.label}>
                  <a
                    href={l.href}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="focus-ring group flex items-baseline justify-between gap-4 border-b border-paper/20 py-6"
                  >
                    <span className="eyebrow !text-paper/50">{l.label}</span>
                    <span className="font-serif text-2xl transition-colors group-hover:text-accent md:text-4xl">
                      {l.label} <span aria-hidden className="inline-block transition-transform duration-300 group-hover:-translate-y-0.5 group-hover:translate-x-0.5">↗</span>
                    </span>
                  </a>
                </li>
              ))}
            </ul>
          </Reveal>
        </div>

        <div className="mt-28 flex flex-wrap items-center justify-between gap-4 border-t border-paper/20 py-6 md:mt-40">
          <span className="eyebrow !text-paper/50">© {new Date().getFullYear()} {profile.name}</span>
          <a href="#top" className="focus-ring eyebrow !text-paper/50 transition-colors hover:!text-paper">
            Back to top ↑
          </a>
        </div>
      </div>
    </footer>
  );
}

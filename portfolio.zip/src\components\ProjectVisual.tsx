import Image from "next/image";
import type { Project } from "@/data/content";

const themes = {
  ink: { bg: "bg-ink", fg: "#EFECE6", accent: "#D9482B" },
  accent: { bg: "bg-accent", fg: "#121110", accent: "#EFECE6" },
  paper: { bg: "bg-paper-2", fg: "#121110", accent: "#D9482B" },
} as const;

/** Real screenshot if `image` is set; otherwise a clearly-labelled generated placeholder. */
export function ProjectVisual({ project }: { project: Project }) {
  if (project.image) {
    return (
      <Image
        src={project.image}
        alt={`${project.name} screenshot`}
        fill
        sizes="(min-width: 1024px) 60vw, 100vw"
        className="object-cover"
      />
    );
  }
  const t = themes[project.accent];
  return (
    <div className={`absolute inset-0 ${t.bg}`} role="img" aria-label={`${project.name} — screenshot placeholder`}>
      <svg viewBox="0 0 800 500" preserveAspectRatio="xMidYMid slice" className="h-full w-full" fill="none">
        <g stroke={t.fg} strokeOpacity=".25" strokeWidth="1">
          <rect x="60" y="60" width="680" height="380" />
          <line x1="60" y1="104" x2="740" y2="104" />
          <line x1="190" y1="104" x2="190" y2="440" />
          {[150, 200, 250, 300, 350].map((y) => (
            <line key={y} x1="214" y1={y} x2="716" y2={y} strokeDasharray="2 6" />
          ))}
        </g>
        <g fill={t.fg} fillOpacity=".3">
          <circle cx="82" cy="82" r="5" />
          <circle cx="100" cy="82" r="5" />
          <circle cx="118" cy="82" r="5" />
          {[0, 1, 2, 3].map((i) => (
            <rect key={i} x="78" y={130 + i * 30} width="90" height="8" />
          ))}
        </g>
        <path
          d="M214 380 C 290 300, 330 360, 400 280 S 520 230, 580 260 S 680 190, 716 170"
          stroke={t.accent}
          strokeWidth="3"
        />
        <circle cx="716" cy="170" r="7" fill={t.accent} />
        <text
          x="214"
          y="136"
          fill={t.fg}
          fillOpacity=".55"
          fontSize="12"
          fontFamily="ui-monospace, monospace"
          letterSpacing="3"
        >
          SCREENSHOT PLACEHOLDER
        </text>
      </svg>
    </div>
  );
}

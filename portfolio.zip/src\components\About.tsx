import { about, profile } from "@/data/content";
import { Reveal } from "./Reveal";
import { SectionHeading } from "./SectionHeading";

export function About() {
  return (
    <section id="about" className="py-28 md:py-44">
      <div className="container-x">
        <SectionHeading index="01" label="About" lines={["Design-minded,", <>engineering <em>led.</em></>]} />

        <div className="grid grid-cols-12 gap-y-14">
          <Reveal className="col-span-12 lg:col-span-5">
            <p className="font-serif text-[clamp(1.6rem,2.6vw,2.4rem)] leading-[1.2]">
              {about.lead}
            </p>
            <div className="mt-12 flex items-end gap-4">
              <span className="font-serif text-[7rem] leading-[0.8] text-accent">{profile.years}</span>
              <span className="eyebrow pb-1 !text-ink">
                Years building
                <br />
                for the web
              </span>
            </div>
          </Reveal>

          <div className="col-span-12 lg:col-span-6 lg:col-start-7">
            <div className="space-y-6 text-base leading-[1.75] text-ink/80 md:text-lg">
              {about.paragraphs.map((p, i) => (
                <Reveal key={i} delay={i * 0.08}>
                  <p>{p}</p>
                </Reveal>
              ))}
            </div>

            <ul className="mt-14 border-t border-ink/15">
              {about.pillars.map((p, i) => (
                <Reveal as="li" key={p.label} delay={i * 0.05}>
                  <div className="group flex items-baseline justify-between gap-6 border-b border-ink/15 py-5 transition-colors hover:border-ink">
                    <span className="flex items-baseline gap-5">
                      <span className="eyebrow !text-accent">0{i + 1}</span>
                      <span className="text-lg transition-transform duration-500 group-hover:translate-x-2 md:text-xl">
                        {p.label}
                      </span>
                    </span>
                    <span className="eyebrow hidden text-right sm:block">{p.note}</span>
                  </div>
                </Reveal>
              ))}
            </ul>
          </div>
        </div>
      </div>
    </section>
  );
}

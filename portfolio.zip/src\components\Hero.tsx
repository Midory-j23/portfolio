"use client";

import { motion, useScroll, useTransform } from "framer-motion";
import { useRef } from "react";
import { profile } from "@/data/content";
import { LineReveal, Reveal } from "./Reveal";

function Orbit() {
  return (
    <div className="relative aspect-square w-full max-w-[520px]" aria-hidden>
      <div className="absolute inset-0 rounded-full border border-ink/15" />
      <div className="absolute inset-[12%] rounded-full border border-ink/15" />
      <div className="absolute inset-[26%] rounded-full border border-ink/15" />
      <div className="absolute inset-[40%] rounded-full bg-ink" />
      {/* crosshair */}
      <div className="absolute left-1/2 top-0 h-full w-px bg-ink/10" />
      <div className="absolute left-0 top-1/2 h-px w-full bg-ink/10" />
      {/* slow dashed ring */}
      <div className="absolute inset-[6%] animate-spin-slow">
        <svg viewBox="0 0 100 100" className="h-full w-full">
          <circle
            cx="50"
            cy="50"
            r="49.5"
            fill="none"
            stroke="#121110"
            strokeOpacity=".35"
            strokeWidth=".25"
            strokeDasharray="0.6 2.4"
          />
        </svg>
        <span className="absolute left-1/2 top-0 h-3 w-3 -translate-x-1/2 -translate-y-1/2 rounded-full bg-accent" />
      </div>
      <div className="absolute inset-[19%] animate-spin-rev">
        <span className="absolute bottom-0 left-1/2 h-2 w-2 -translate-x-1/2 translate-y-1/2 rounded-full border border-ink bg-paper" />
      </div>
      <span className="eyebrow absolute -right-1 top-[8%] hidden rotate-90 origin-right sm:block">
        Frontend
      </span>
      <span className="eyebrow absolute -left-1 bottom-[8%] hidden -rotate-90 origin-left sm:block">
        Backend
      </span>
      <span className="eyebrow absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 !text-paper">
        {profile.wordmark}
      </span>
    </div>
  );
}

export function Hero() {
  const ref = useRef<HTMLElement>(null);
  const { scrollYProgress } = useScroll({ target: ref, offset: ["start start", "end start"] });
  const y = useTransform(scrollYProgress, [0, 1], [0, 120]);
  const fade = useTransform(scrollYProgress, [0, 0.8], [1, 0]);

  return (
    <section
      id="top"
      ref={ref}
      className="relative flex min-h-[100svh] flex-col justify-end overflow-hidden pt-28 md:pt-32"
    >
      <div className="container-x relative grid flex-1 grid-cols-12 items-center gap-y-12">
        <motion.div style={{ opacity: fade }} className="col-span-12 lg:col-span-8">
          <Reveal className="mb-8 flex flex-wrap items-center gap-x-6 gap-y-2">
            {profile.available && (
              <span className="eyebrow flex items-center gap-2 !text-ink">
                <span className="relative flex h-2 w-2">
                  <span className="absolute inline-flex h-full w-full animate-pulseDot rounded-full bg-accent" />
                  <span className="relative inline-flex h-2 w-2 rounded-full bg-accent" />
                </span>
                {profile.availability}
              </span>
            )}
            <span className="eyebrow">{profile.role} · {profile.years} yrs</span>
          </Reveal>

          <LineReveal
            as="h1"
            animateOnMount
            delay={0.15}
            className="h-display text-[clamp(2.9rem,12vw,5.5rem)] sm:text-[clamp(3.5rem,9vw,6.5rem)] lg:text-[clamp(4rem,6.6vw,8.5rem)]"
            lines={[
              "Building Digital",
              "Experiences Through",
              <span key="c">
                Code <em className="text-accent">&amp;</em> Creativity.
              </span>,
            ]}
          />

          <Reveal delay={0.7} className="mt-10 grid gap-10 md:grid-cols-[minmax(0,32rem)_auto] md:items-end md:gap-16">
            <p className="text-lg leading-relaxed text-ink/80 md:text-xl">
              I&rsquo;m a Software Developer with 3 years of experience creating modern web
              applications, intuitive interfaces, and technology-driven solutions.
            </p>
            <div className="flex flex-wrap gap-3">
              <a
                href="#projects"
                className="focus-ring group inline-flex items-center gap-3 bg-ink px-7 py-4 text-sm text-paper transition-colors hover:bg-accent"
              >
                View My Work
                <span className="transition-transform duration-300 group-hover:translate-y-0.5" aria-hidden>
                  ↓
                </span>
              </a>
              <a
                href="#contact"
                className="focus-ring group inline-flex items-center gap-3 border border-ink px-7 py-4 text-sm transition-colors hover:bg-ink hover:text-paper"
              >
                Let&rsquo;s Talk
                <span className="transition-transform duration-300 group-hover:translate-x-1" aria-hidden>
                  →
                </span>
              </a>
            </div>
          </Reveal>
        </motion.div>

        <motion.div
          style={{ y }}
          className="col-span-12 flex justify-center lg:col-span-4 lg:justify-end"
        >
          <motion.div
            className="w-full max-w-[340px] lg:max-w-[420px]"
            initial={{ opacity: 0, scale: 0.92 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 1.4, delay: 0.5, ease: [0.22, 1, 0.36, 1] }}
          >
            <Orbit />
          </motion.div>
        </motion.div>
      </div>

      <div className="container-x">
        <div className="mt-12 flex items-center justify-between border-t border-ink/15 py-5">
          <span className="eyebrow">{profile.location}</span>
          <a href="#about" className="focus-ring eyebrow flex items-center gap-3 !text-ink">
            Scroll
            <span className="relative block h-8 w-px overflow-hidden bg-ink/20" aria-hidden>
              <span className="absolute inset-0 animate-scrollLine bg-ink" />
            </span>
          </a>
          <span className="eyebrow hidden sm:block">© {new Date().getFullYear()}</span>
        </div>
      </div>
    </section>
  );
}

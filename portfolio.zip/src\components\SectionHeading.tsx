import { LineReveal, Reveal } from "./Reveal";

export function SectionHeading({
  index,
  label,
  lines,
  invert = false,
}: {
  index: string;
  label: string;
  lines: React.ReactNode[];
  invert?: boolean;
}) {
  return (
    <div className="mb-14 md:mb-24">
      <Reveal
        className={`mb-8 flex items-center gap-4 border-t pt-4 ${
          invert ? "border-paper/20" : "border-ink/15"
        }`}
      >
        <span className="eyebrow !text-accent">{index}</span>
        <span className={`eyebrow ${invert ? "!text-paper/60" : ""}`}>{label}</span>
      </Reveal>
      <LineReveal
        lines={lines}
        className="h-display text-[clamp(2.75rem,8vw,7rem)]"
      />
    </div>
  );
}

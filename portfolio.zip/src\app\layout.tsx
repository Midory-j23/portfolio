import type { Metadata, Viewport } from "next";
import { Instrument_Serif, Inter_Tight, JetBrains_Mono } from "next/font/google";
import "./globals.css";
import { profile } from "@/data/content";

const serif = Instrument_Serif({
  subsets: ["latin"],
  weight: "400",
  style: ["normal", "italic"],
  variable: "--font-serif",
  display: "swap",
});
const sans = Inter_Tight({
  subsets: ["latin"],
  variable: "--font-sans",
  display: "swap",
});
const mono = JetBrains_Mono({
  subsets: ["latin"],
  variable: "--font-mono",
  display: "swap",
});

const description =
  "Software Developer with 3 years of experience in frontend engineering, UI/UX design and backend development — building modern web applications and AI-powered products.";

export const metadata: Metadata = {
  title: `${profile.name} — Software Developer`,
  description,
  keywords: [
    "Software Developer",
    "Frontend Developer",
    "React",
    "FastAPI",
    "UI/UX Design",
    "Portfolio",
  ],
  openGraph: {
    title: `${profile.name} — Software Developer`,
    description,
    type: "website",
  },
  twitter: { card: "summary_large_image", title: `${profile.name} — Software Developer`, description },
};

export const viewport: Viewport = { themeColor: "#EFECE6" };

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" className={`${serif.variable} ${sans.variable} ${mono.variable}`}>
      <body>{children}</body>
    </html>
  );
}

import { projects, type Project } from "@/data/content";
import { ProjectVisual } from "./ProjectVisual";
import { Reveal } from "./Reveal";
import { SectionHeading } from "./SectionHeading";

function LinkOrNote({ href, label }: { href?: string; label: string }) {
  if (!href) {
    return <span className="eyebrow border-b border-dashed border-ink/30 pb-1">{label} · soon</span>;
  }
  return (
    <a
      href={href}
      target="_blank"
      rel="noopener noreferrer"
      className="focus-ring group inline-flex items-center gap-2 border-b border-ink pb-1 text-sm transition-colors hover:border-accent hover:text-accent"
    >
      {label}
      <span className="transition-transform duration-300 group-hover:-translate-y-0.5 group-hover:translate-x-0.5" aria-hidden>
        ↗
      </span>
    </a>
  );
}

function ProjectRow({ project, flip }: { project: Project; flip: boolean }) {
  const href = project.demoUrl ?? project.repoUrl;
  return (
    <article className="grid grid-cols-12 gap-x-0 gap-y-8 lg:gap-x-10 border-t border-ink/15 py-14 md:py-20">
      <Reveal className={`col-span-12 min-w-0 lg:col-span-7 ${flip ? "lg:order-2" : ""}`}>
        <div
          className="group relative aspect-[16/10] overflow-hidden"
          data-cursor={href ? "View" : undefined}
        >
          <div className="absolute inset-0 transition-transform duration-[1200ms] ease-[cubic-bezier(.22,1,.36,1)] group-hover:scale-[1.05]">
            <ProjectVisual project={project} />
          </div>
          <div className="pointer-events-none absolute inset-0 ring-1 ring-inset ring-ink/10" />
          {href && (
            <a
              href={href}
              target="_blank"
              rel="noopener noreferrer"
              className="focus-ring absolute inset-0"
              aria-label={`Open ${project.name}`}
            />
          )}
        </div>
      </Reveal>

      <Reveal delay={0.1} className={`col-span-12 flex min-w-0 flex-col lg:col-span-5 ${flip ? "lg:order-1" : ""}`}>
        <div className="flex flex-wrap items-baseline justify-between gap-x-4 gap-y-2">
          <span className="font-serif text-6xl leading-none text-accent">{project.index}</span>
          <span className="eyebrow text-right">{project.category}</span>
        </div>
        <h3 className="mt-8 break-words font-serif text-[clamp(2rem,4vw,3.6rem)] leading-[1] tracking-tight">
          {project.name}
        </h3>

        <dl className="mt-8 space-y-6 text-base leading-relaxed">
          <div>
            <dt className="eyebrow mb-2">Overview</dt>
            <dd className="text-ink/80">{project.overview}</dd>
          </div>
          <div>
            <dt className="eyebrow mb-2">My contribution</dt>
            <dd className="text-muted italic">{project.contribution}</dd>
          </div>
        </dl>

        <ul className="mt-8 flex flex-wrap gap-2" aria-label="Technologies">
          {project.technologies.map((t) => (
            <li key={t} className="eyebrow border border-ink/25 px-3 py-1.5 !text-ink">
              {t}
            </li>
          ))}
        </ul>

        <div className="mt-10 flex flex-wrap gap-x-8 gap-y-3 lg:mt-auto lg:pt-10">
          <LinkOrNote href={project.demoUrl} label="Live demo" />
          <LinkOrNote href={project.repoUrl} label="GitHub" />
        </div>
      </Reveal>
    </article>
  );
}

export function Projects() {
  return (
    <section id="projects" className="py-28 md:py-44">
      <div className="container-x">
        <SectionHeading index="03" label="Selected Work" lines={["Featured", <em>projects.</em>]} />
        <div className="border-b border-ink/15">
          {projects.map((p, i) => (
            <ProjectRow key={p.name} project={p} flip={i % 2 === 1} />
          ))}
        </div>
      </div>
    </section>
  );
}

import { skills } from "@/data/content";
import { Reveal } from "./Reveal";
import { SectionHeading } from "./SectionHeading";

export function Skills() {
  return (
    <section id="skills" className="bg-paper-2 py-28 md:py-44">
      <div className="container-x">
        <SectionHeading index="04" label="Toolkit" lines={["Skills &", <>technologies<em>.</em></>]} />

        <div className="border-t border-ink/15">
          {skills.map((s, i) => (
            <Reveal key={s.group}>
              <div className="group grid grid-cols-12 gap-x-0 gap-y-3 md:gap-x-6 border-b border-ink/15 py-8 transition-colors duration-500 hover:bg-paper md:py-10">
                <div className="col-span-12 flex items-baseline gap-5 md:col-span-4 md:pl-2">
                  <span className="eyebrow !text-accent">0{i + 1}</span>
                  <h3 className="eyebrow !text-ink">{s.group}</h3>
                </div>
                <ul className="col-span-12 flex flex-wrap items-baseline gap-x-3 gap-y-1 md:col-span-8">
                  {s.items.map((item, j) => (
                    <li
                      key={item}
                      className="flex items-baseline gap-3 font-serif text-[clamp(1.6rem,3vw,2.6rem)] leading-tight transition-colors duration-300 hover:text-accent"
                    >
                      {item}
                      {j < s.items.length - 1 && (
                        <span aria-hidden className="text-ink/25">/</span>
                      )}
                    </li>
                  ))}
                </ul>
              </div>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
